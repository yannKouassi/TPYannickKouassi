public interface Louable {
    public void louer() ;
    public void retourner();

}
