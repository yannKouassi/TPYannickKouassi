public class VehiculeIndisponibleException extends RuntimeException {
  public VehiculeIndisponibleException(String message) {
    super();
  }
}
